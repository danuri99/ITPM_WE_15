﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TimeTableManagementSystem;

namespace Timetable_Management_System.Location
{
    public partial class Main_Window : Form
    {
        public Main_Window()
        {
            InitializeComponent();
            hideSubMenu();
            showChildForms(new Dashboard());
            
            menuStrip1.Renderer = new MyRenderer();

            hideInfoBox();
        }

        private void hideSubMenu()
        {
            panel4.Visible = false;
            panel5.Visible = false;
            panel6.Visible = false;
            panel7.Visible = false;
            panel8.Visible = false;
            panel12.Visible = false;
            panel13.Visible = false;

        }

       
        private void showSubMenu(Panel p)
        {
            if (p.Visible == false)
            {
                hideSubMenu();
                p.Visible = true;
            }
            else
            {
                p.Visible = false;
            }

        }

        private void hideInfoBox()
        {
            label1.Visible = false;
        }

        private void showInfoBox(Label l)
        {
            if (l.Visible == false)
            {
                hideInfoBox();
                l.Visible = true;
            }
            else
            {
                l.Visible = false;
            }
        }


        private Form currentForm = null;

        private void showChildForms(Form f)
        {
            if (currentForm != null)
            {
                currentForm.Close();

            }

            currentForm = f;
            f.TopLevel = false;
            f.FormBorderStyle = FormBorderStyle.None;
            f.Dock = DockStyle.Top;

            panel11.Controls.Add(f);
            panel11.Tag = f;
            f.BringToFront();
            f.Show();

        }



        private void studentToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            showChildForms(new WindowsFormsApp1.Student.Add_Student_Group());

            locationAllocationToolStripMenuItem.BackColor = System.Drawing.Color.CadetBlue;
            dashboardToolStripMenuItem.BackColor = System.Drawing.Color.CadetBlue;
            sessionAllocationToolStripMenuItem.BackColor = System.Drawing.Color.CadetBlue;
            locationAllocationToolStripMenuItem1.BackColor = System.Drawing.Color.CadetBlue;
            timetablesToolStripMenuItem.BackColor = System.Drawing.Color.CadetBlue;
        }

        private void button7_Click(object sender, EventArgs e)
        {
            showSubMenu(panel8);
        }

        private void panel8_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            showSubMenu(panel4);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            showSubMenu(panel5);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            showSubMenu(panel6);
        }

        private void button6_Click(object sender, EventArgs e)
        {
            showSubMenu(panel7);
        }

        private void button8_Click(object sender, EventArgs e)
        {
            showChildForms(new Add_Location());
        }

        private void button9_Click(object sender, EventArgs e)
        {
            showChildForms(new Manage_Locations());
        }

        private void sessionAllocationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            sessionAllocationToolStripMenuItem.BackColor = System.Drawing.Color.Gray;
            dashboardToolStripMenuItem.BackColor = System.Drawing.Color.CadetBlue;       
            locationAllocationToolStripMenuItem.BackColor = System.Drawing.Color.CadetBlue;
            locationAllocationToolStripMenuItem1.BackColor = System.Drawing.Color.CadetBlue;
            timetablesToolStripMenuItem.BackColor = System.Drawing.Color.CadetBlue;
        }

        private void pictureBox1_Click_1(object sender, EventArgs e)
        {

        }

        private void dashboardToolStripMenuItem_Click(object sender, EventArgs e)
        {
            showChildForms(new Dashboard());

            dashboardToolStripMenuItem.BackColor = System.Drawing.Color.Gray;
            sessionAllocationToolStripMenuItem.BackColor = System.Drawing.Color.CadetBlue;
            locationAllocationToolStripMenuItem.BackColor = System.Drawing.Color.CadetBlue;
            locationAllocationToolStripMenuItem1.BackColor = System.Drawing.Color.CadetBlue;
            timetablesToolStripMenuItem.BackColor = System.Drawing.Color.CadetBlue;

        }

        //Add working days & hours button
        private void button17_Click(object sender, EventArgs e)
        {
            showChildForms(new Time_Table_Management_System.AddWorkingDaysHours1());
        }

        //Manage working days & hours
        private void button18_Click(object sender, EventArgs e)
        {
            showChildForms(new Time_Table_Management_System.ManageWorkingdayshours());
        }

        private void button16_Click(object sender, EventArgs e)
        {
            showSubMenu(panel12);
        }

        private class MyRenderer : ToolStripProfessionalRenderer
        {
            protected override void OnRenderMenuItemBackground(ToolStripItemRenderEventArgs e)
            {
                if (!e.Item.Selected) base.OnRenderMenuItemBackground(e);
                else
                {
                    Rectangle rc = new Rectangle(Point.Empty, e.Item.Size);
                    e.Graphics.FillRectangle(Brushes.Gray, rc);
                    e.Graphics.DrawRectangle(Pens.Gray, 1, 0, rc.Width - 2, rc.Height - 1);
                }
            }
        }

        private void locationAllocationToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            locationAllocationToolStripMenuItem1.BackColor = System.Drawing.Color.Gray;

            dashboardToolStripMenuItem.BackColor = System.Drawing.Color.CadetBlue;
            sessionAllocationToolStripMenuItem.BackColor = System.Drawing.Color.CadetBlue;
            locationAllocationToolStripMenuItem.BackColor = System.Drawing.Color.CadetBlue;
            timetablesToolStripMenuItem.BackColor = System.Drawing.Color.CadetBlue;
        }

        private void sessionRoomsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            showChildForms(new Allocate_Suitable_Location());
            locationAllocationToolStripMenuItem1.BackColor = System.Drawing.Color.Gray;

            dashboardToolStripMenuItem.BackColor = System.Drawing.Color.CadetBlue;
            sessionAllocationToolStripMenuItem.BackColor = System.Drawing.Color.CadetBlue;
            locationAllocationToolStripMenuItem.BackColor = System.Drawing.Color.CadetBlue;
            timetablesToolStripMenuItem.BackColor = System.Drawing.Color.CadetBlue;
        }

        private void specialRoomsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            showChildForms(new Add_Suitable_Room());
            locationAllocationToolStripMenuItem1.BackColor = System.Drawing.Color.Gray;

            dashboardToolStripMenuItem.BackColor = System.Drawing.Color.CadetBlue;
            sessionAllocationToolStripMenuItem.BackColor = System.Drawing.Color.CadetBlue;
            locationAllocationToolStripMenuItem.BackColor = System.Drawing.Color.CadetBlue;
            timetablesToolStripMenuItem.BackColor = System.Drawing.Color.CadetBlue;
        }

        private void locationAllocationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            showChildForms(new WindowsFormsApp1.Student.Session_Allocation());
            
            locationAllocationToolStripMenuItem.BackColor = System.Drawing.Color.Gray;
            dashboardToolStripMenuItem.BackColor = System.Drawing.Color.CadetBlue;
            sessionAllocationToolStripMenuItem.BackColor = System.Drawing.Color.CadetBlue;
            locationAllocationToolStripMenuItem1.BackColor = System.Drawing.Color.CadetBlue;
            timetablesToolStripMenuItem.BackColor = System.Drawing.Color.CadetBlue;
        }

        private void timetablesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            showChildForms(new TimeTableManagementSystem.GenerateTimeTable());

            timetablesToolStripMenuItem.BackColor = System.Drawing.Color.Gray;
            dashboardToolStripMenuItem.BackColor = System.Drawing.Color.CadetBlue;
            sessionAllocationToolStripMenuItem.BackColor = System.Drawing.Color.CadetBlue;
            locationAllocationToolStripMenuItem.BackColor = System.Drawing.Color.CadetBlue;
            locationAllocationToolStripMenuItem1.BackColor = System.Drawing.Color.CadetBlue;
        }

        private void panel11_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button10_Click(object sender, EventArgs e)
        {
            showChildForms(new TimeTableManagementSystem.AddLecturers());

            locationAllocationToolStripMenuItem.BackColor = System.Drawing.Color.CadetBlue;
            dashboardToolStripMenuItem.BackColor = System.Drawing.Color.CadetBlue;
            sessionAllocationToolStripMenuItem.BackColor = System.Drawing.Color.CadetBlue;
            locationAllocationToolStripMenuItem1.BackColor = System.Drawing.Color.CadetBlue;
            timetablesToolStripMenuItem.BackColor = System.Drawing.Color.CadetBlue;
        }

        private void pictureBox2_Click_1(object sender, EventArgs e)
        {

        }

        private void button11_Click(object sender, EventArgs e)
        {
            showChildForms(new TimeTableManagementSystem.ManageLecturers());

            locationAllocationToolStripMenuItem.BackColor = System.Drawing.Color.CadetBlue;
            dashboardToolStripMenuItem.BackColor = System.Drawing.Color.CadetBlue;
            sessionAllocationToolStripMenuItem.BackColor = System.Drawing.Color.CadetBlue;
            locationAllocationToolStripMenuItem1.BackColor = System.Drawing.Color.CadetBlue;
            timetablesToolStripMenuItem.BackColor = System.Drawing.Color.CadetBlue;
        }

        private void button12_Click(object sender, EventArgs e)
        {
            showChildForms(new TimeTableManagementSystem.AddSubject());

            locationAllocationToolStripMenuItem.BackColor = System.Drawing.Color.CadetBlue;
            dashboardToolStripMenuItem.BackColor = System.Drawing.Color.CadetBlue;
            sessionAllocationToolStripMenuItem.BackColor = System.Drawing.Color.CadetBlue;
            locationAllocationToolStripMenuItem1.BackColor = System.Drawing.Color.CadetBlue;
            timetablesToolStripMenuItem.BackColor = System.Drawing.Color.CadetBlue;
        }

        private void button13_Click(object sender, EventArgs e)
        {
            showChildForms(new TimeTableManagementSystem.ManageSubjects());

            locationAllocationToolStripMenuItem.BackColor = System.Drawing.Color.CadetBlue;
            dashboardToolStripMenuItem.BackColor = System.Drawing.Color.CadetBlue;
            sessionAllocationToolStripMenuItem.BackColor = System.Drawing.Color.CadetBlue;
            locationAllocationToolStripMenuItem1.BackColor = System.Drawing.Color.CadetBlue;
            timetablesToolStripMenuItem.BackColor = System.Drawing.Color.CadetBlue;
        }

        private void manageSessionsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            showChildForms(new TimeTableManagementSystem.AddSessions());

            locationAllocationToolStripMenuItem.BackColor = System.Drawing.Color.CadetBlue;
            dashboardToolStripMenuItem.BackColor = System.Drawing.Color.CadetBlue;
            sessionAllocationToolStripMenuItem.BackColor = System.Drawing.Color.CadetBlue;
            locationAllocationToolStripMenuItem1.BackColor = System.Drawing.Color.CadetBlue;
            timetablesToolStripMenuItem.BackColor = System.Drawing.Color.CadetBlue;
        }

        private void manageSessionsToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            showChildForms(new TimeTableManagementSystem.ManageSessions());

            locationAllocationToolStripMenuItem.BackColor = System.Drawing.Color.CadetBlue;
            dashboardToolStripMenuItem.BackColor = System.Drawing.Color.CadetBlue;
            sessionAllocationToolStripMenuItem.BackColor = System.Drawing.Color.CadetBlue;
            locationAllocationToolStripMenuItem1.BackColor = System.Drawing.Color.CadetBlue;
            timetablesToolStripMenuItem.BackColor = System.Drawing.Color.CadetBlue;
        }

        private void manageSessionsToolStripMenuItem_MouseHover(object sender, EventArgs e)
        {
            
        }

        //Manage timeslots
        private void button21_Click(object sender, EventArgs e)
        {
            showChildForms(new Time_Table_Management_System.Form1());
        }

        private void button20_Click(object sender, EventArgs e)
        {

        }

        private void button19_Click(object sender, EventArgs e)
        {
            showSubMenu(panel13);
        }

        //info button
        private void pictureBox3_Click(object sender, EventArgs e)
        {
            showInfoBox(label1);
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            showChildForms(new WindowsFormsApp1.Student.Manage_Students());

            locationAllocationToolStripMenuItem.BackColor = System.Drawing.Color.CadetBlue;
            dashboardToolStripMenuItem.BackColor = System.Drawing.Color.CadetBlue;
            sessionAllocationToolStripMenuItem.BackColor = System.Drawing.Color.CadetBlue;
            locationAllocationToolStripMenuItem1.BackColor = System.Drawing.Color.CadetBlue;
            timetablesToolStripMenuItem.BackColor = System.Drawing.Color.CadetBlue;
        }

        private void button15_Click(object sender, EventArgs e)
        {
            showChildForms(new WindowsFormsApp1.Student.Ma());

            locationAllocationToolStripMenuItem.BackColor = System.Drawing.Color.CadetBlue;
            dashboardToolStripMenuItem.BackColor = System.Drawing.Color.CadetBlue;
            sessionAllocationToolStripMenuItem.BackColor = System.Drawing.Color.CadetBlue;
            locationAllocationToolStripMenuItem1.BackColor = System.Drawing.Color.CadetBlue;
            timetablesToolStripMenuItem.BackColor = System.Drawing.Color.CadetBlue;
        }
    }
}
